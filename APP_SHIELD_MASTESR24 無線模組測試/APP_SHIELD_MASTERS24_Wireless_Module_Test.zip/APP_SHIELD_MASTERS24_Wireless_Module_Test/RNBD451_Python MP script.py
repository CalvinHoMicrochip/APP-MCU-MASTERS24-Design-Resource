import serial
import serial.tools.list_ports
import time
import msvcrt

def select_com_port():
    ports = serial.tools.list_ports.comports()
    if not ports:
        raise Exception("No COM ports found.")

    print("Available COM ports:")
    for i, port in enumerate(ports):
        print(f"{i + 1}: {port.device}")

    while True:
        try:
            selection = int(input("Select COM port by number: "))
            if 1 <= selection <= len(ports):
                return ports[selection - 1].device
            else:
                print("Invalid selection. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def main():
    try:
        com_port = select_com_port()
        ser = serial.Serial(com_port, baudrate=115200, timeout=1)
        ser.write_timeout = 1

        # Setting Transmit as CR+LF and enabling local echo
        ser.newline = '\r\n'
        ser.echo = True

        if ser.is_open:
            print(f"Connected to {ser.port} at {ser.baudrate} baudrate")
            
            # Send "$$$" command
            command = "$$$"
            ser.write(command.encode('utf-8'))
            print(f"Command sent: {command}")
            while True:
                response = ser.read_all().decode('utf-8', errors='ignore')
                if response:
                    print(f"Response: {response}")
                if "CMD" in response:
                    break
                time.sleep(0.1)

            # Immediately send "d" command after receiving "CMD"
            command = "d"
            ser.write(command.encode('utf-8'))
            print(f"Command sent: {command}")
            time.sleep(2)
            ser.write(b'\r\n')  # Simulate pressing Enter key

            name_value = ""
            services_received = False
            cmd_received = False
            while True:
                response = ser.read_all().decode('utf-8', errors='ignore')
                if response:
                    print(f"Response: {response}")
                    if "Name=" in response:
                        name_value = response.split("Name=")[1].split()[0]
                    if "Services=C0" in response:
                        services_received = True
                    if "CMD" in response:
                        cmd_received = True
                    if services_received and cmd_received:
                        break
                time.sleep(0.1)

            # Delay before sending next command
            time.sleep(1)

            # Send "---" command and simulate pressing Enter key, wait for "END" response
            command = "---"
            ser.write(command.encode('utf-8'))
            print(f"Command sent: {command}")
            ser.write(b'\r\n')  # Simulate pressing Enter key
            while True:
                response = ser.read_all().decode('utf-8', errors='ignore')
                if response:
                    print(f"Response: {response}")
                if "END" in response:
                    break
                time.sleep(0.1)

            # Print start message before waiting for 90KB of data
            print("Start UART Transparent Test for 100KB Data")
            print(f"Find \"Name\": {name_value}")

            # Wait for 90KB of data
            data_received = b''
            while len(data_received) < 90 * 1024:  # 90KB
                response = ser.read_all()
                if response:
                    data_received += response
                    print(f"Data received: {len(data_received)} bytes")
                time.sleep(0.1)

            print("100KB of data received. Closing serial port.")
            ser.close()

            # Wait for Enter key to exit
            print("Press Enter to quit.")
            while True:
                if msvcrt.kbhit() and ord(msvcrt.getch()) == 13:  # 13 is the ASCII code for 'Enter'
                    print("Enter key pressed. Exiting.")
                    break

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
