#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "lwip/udp.h"
#include "definitions.h"
#include "udp_handler.h"

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                      DEFINES AND LOCAL VARIABLES                     */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

typedef struct
{
    struct udp_pcb *sock;
    struct ip_addr remoteIp;
} UdpSpeedLocal_t;

static UdpSpeedLocal_t m;
extern SYSTICK_OBJECT systick;

extern uint8_t Length;
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                      PRIVATE FUNCTION PROTOTYPES                     */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static void OnReceive(void *arg, struct udp_pcb *upcb, struct pbuf *pb, struct ip_addr *addr, uint16_t port);

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                         PUBLIC FUNCTIONS                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

bool UdpHandler_Init(void)
{
    memset(&m, 0, sizeof (UdpSpeedLocal_t));
    ipaddr_aton(UDP_SPEED_BROADCAST_IP, &m.remoteIp);
    m.sock = udp_new();
    if (!m.sock)
    {
        return false;
    }
    if (ERR_OK != udp_bind(m.sock, IP_ADDR_ANY, UDP_SPEED_PORT))
    {
        return false;
    }
    udp_recv(m.sock, OnReceive, &m);
    return true;
}

int32_t UdpHandler_Send(uint8_t *buffer, uint16_t len)
{
    err_t result;
    struct pbuf *pb = NULL;
    if (!m.sock)
    {
        return ERR_CONN;
    }
    pb = pbuf_alloc(PBUF_TRANSPORT, len, PBUF_RAM);
    if (!pb)
    {
        return ERR_MEM;
    }
    assert(pb->len == len);
    pbuf_take(pb, buffer, len);
    result = udp_sendto(m.sock, pb, &m.remoteIp, UDP_SPEED_PORT);
    if (ERR_OK != result)
    {
        return ERR_WOULDBLOCK;
    }
    pbuf_free(pb);
    return ERR_OK;
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                            GET ID                                    */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static uint16_t UdpHandler_getID(uint8_t* p_buf)
{
    return (uint16_t) (p_buf[0] | p_buf[1] << 8);
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                  PRIVATE FUNCTION IMPLEMENTATIONS                    */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static void OnReceive(void *arg, struct udp_pcb *upcb, struct pbuf *pb, struct ip_addr *addr, uint16_t port)
{
    (void) arg;
    (void) upcb;
    (void) port;
    uint16_t msgID = UdpHandler_getID(pb->payload);
    
    #if Training_Lab == Lab1
    if (pb->len >= 4)
    #elif Training_Lab == Lab2
    if (pb->len >= 6)
    #elif Training_Lab == Lab3
    if (pb->len >= (5+Length))
    #endif
    {
        switch (msgID)
        {
        case SWITCH_VALUE:
            UdpHandler_CB_OnReceive(pb->payload, pb->len);
            break;
        default:
            break;
        }
    }
    pbuf_free(pb);
}