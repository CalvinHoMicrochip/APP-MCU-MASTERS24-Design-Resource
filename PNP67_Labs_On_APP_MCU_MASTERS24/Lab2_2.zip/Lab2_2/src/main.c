/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include <stdio.h>
#include "definitions.h"                // SYS function prototypes
#include <xc.h>

volatile          bool RTC_Matched = false ;
unsigned int    LoopCounter = 0 ;
char              DMA_SourceBuf[128];

void    RTC_ISR(RTC_TIMER32_INT_MASK intCause, uintptr_t context)
{
    if((intCause & RTC_TIMER32_INT_MASK_CMP0) == RTC_TIMER32_INT_MASK_CMP0)
        {
            RTC_Matched = true ;
        } 
}

void myDmacInterruptHandler(DMAC_TRANSFER_EVENT event, uintptr_t contextHandle)
{
    DMAC_REGS->CHANNEL[0].DMAC_CHCTRLA |= DMAC_CHCTRLA_ENABLE_Msk;  
}


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    
    //Enable the ADC
    ADC0_Enable();
   
   //ADC Startup Fix 
   for(int i=0; i<1000; i++)
    {
        _nop();
    }    
    
    //Start the TCC1 PWM
    TCC1_PWMStart();
    
    //Start the first ADC conversion
    ADC0_ConversionStart();
    
    DMAC_ChannelTransfer( 0, (const void *)(&ADC0_REGS->ADC_RESULT), 
                        (const void *)(&TCC1_REGS->TCC_CCBUF[2]), 1000); 
    
    DMAC_ChannelCallbackRegister( DMAC_CHANNEL_0,
                                  &myDmacInterruptHandler, (uintptr_t)NULL);
    
    sprintf(DMA_SourceBuf,"\n\rABCDEFGHIJKLMNOPQRSTUVWXYZ %4d",LoopCounter++);       
    
    DMAC_ChannelTransfer( 1, (const void *)(&DMA_SourceBuf[0]), 
            (const void *)( &SERCOM4_REGS->USART_INT.SERCOM_DATA), strlen(DMA_SourceBuf));   

    RTC_Timer32CallbackRegister(RTC_ISR,0);
    RTC_Timer32Start();

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        if (RTC_Matched)
        {
            RTC_Matched = 0 ;
            
            if(!DMAC_ChannelIsBusy ( 1 ))
             {
                 sprintf(DMA_SourceBuf,"\n\rABCDEFGHIJKLMNOPQRSTUVWXYZ %4d",LoopCounter++);                
                 DMAC_REGS->CHANNEL[1].DMAC_CHCTRLA |= DMAC_CHCTRLA_ENABLE_Msk;
                 E54_LED2_Toggle(); 
             }            
        }       
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

