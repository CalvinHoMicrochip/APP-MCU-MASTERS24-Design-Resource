/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "OLED128x64.h"
#define     MCP9800A5_Addr  0b01001101

uint16_t adc_data;

volatile        bool    bTCC0_Overflow = 0 ;
volatile        bool    bIsI2C_DONE = true ;
uint16_t        LoopVar = 0 ;
unsigned char   SERCOM0_wBuf[32];
unsigned char   SERCOM0_rBuf[32];
float           MCP9800_Temp;
unsigned char   ASCII_Buf[64];

void    TCC0_ISR(uint32_t Status,  uintptr_t context)
{
        bTCC0_Overflow = 1 ;
}

void    I2C_ISR(uintptr_t  contest)
{
    if (SERCOM0_I2C_ErrorGet() == SERCOM_I2C_ERROR_NONE )
        bIsI2C_DONE = true ;
}

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    SERCOM0_I2C_CallbackRegister(I2C_ISR,0) ;   
    TCC0_TimerCallbackRegister(TCC0_ISR,(uintptr_t) NULL);
    TCC0_TimerStart();    
    
    bTCC0_Overflow = false ;
    while (bTCC0_Overflow==0)
    {;}
    bTCC0_Overflow = true ;
    
        OLED_Init();
        OLED_CLS();
        OLED_Put8x16Str(0, 0, (const unsigned char*) "APP-MCU-MASTER24") ;    
        OLED_Put8x16Str(0, 2, (const unsigned char*) "MCU: PIC32CK2051") ;  
        
        // Setting configuration of MCP9800A0 
        SERCOM0_wBuf[0] = 0x01 ;            
        SERCOM0_wBuf[1] = 0b01100000;       
        bIsI2C_DONE = 0 ;
        SERCOM0_I2C_Write(MCP9800A5_Addr,SERCOM0_wBuf,2);
        while (bIsI2C_DONE == 0x00) ;                   

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        
        if (bTCC0_Overflow)
        {
            bTCC0_Overflow = 0 ;
            ADC_GlobalEdgeConversionStart();
        
            while (ADC_ChannelResultIsReady(ADC_CH0) == false);
            adc_data = ADC_ResultGet(ADC_CH0);                
            printf("\n\rADC_Value = %4d",adc_data);
            sprintf ((char*)ASCII_Buf,"ADC= %4d",adc_data);
            OLED_Put8x16Str(0,4,(const unsigned char*)ASCII_Buf);
            
        SERCOM0_wBuf[0] = 0x00 ;
        bIsI2C_DONE = 0 ;
        SERCOM0_I2C_WriteRead(MCP9800A5_Addr,SERCOM0_wBuf,1,SERCOM0_rBuf,2);
        while (bIsI2C_DONE == 0x00) ; 

        MCP9800_Temp = (float)(((int)SERCOM0_rBuf[0] <<8) + SERCOM0_rBuf[1]) / 256;
        sprintf((char*)ASCII_Buf,"MCP9800=%2.3f", MCP9800_Temp);
        OLED_Put8x16Str(0, 6, (const unsigned char*)ASCII_Buf) ;              
            
            LED1_Toggle();
            LED2_Toggle();            
            SYS_CONSOLE_PRINT("\n\rReceived Characters: %d",LoopVar++);
        }
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

